clear
clc

AirfoilFile = 'NACA0010_64';
ext = '.txt';
SCADFile = 'NACA0010_64';

n_pts = 50;

FoilRaw = dlmread([AirfoilFile,ext],'',0,0);

% Determines Which point are on the upper/lower surfaces
surfUL = -ones(length(FoilRaw(:,1)),1);
for i = 1:length(FoilRaw(:,1))-1
    if FoilRaw(i,1) > FoilRaw(i+1,1)
        surfUL(i) = 1;
    else
        surfUL(i) = -1;
    end
end
% Recording Trailing Edge Thicknesses
y_te = [FoilRaw(1,2),FoilRaw(end,2)];

% Adjusting Y-Coordinates to have a Cusp Trailing Edge
FoilYAdj(:,1) = FoilRaw(:,1);
for i = 1:length(FoilRaw(:,1))
    if surfUL(i) > 0
        FoilYAdj(i,2) = FoilRaw(i,2) - y_te(1)*FoilYAdj(i,1);
    else
        FoilYAdj(i,2) = FoilRaw(i,2) - y_te(2)*FoilYAdj(i,1);
    end
end

% Outputting Temp Airfoil File for xfoil
TempFile1 = [AirfoilFile,'TEMP1',ext];
fileID = fopen(TempFile1,'w');
for i = 1:length(FoilYAdj(:,1))
    fprintf(fileID,'%10.9f  %10.9f\n',FoilYAdj(i,1),FoilYAdj(i,2));
end
fclose(fileID);

% Generating xfoils input file
TempFile2 = [AirfoilFile,'TEMP2',ext];
InpFile = 'xfoil.inp';
fileID = fopen(InpFile,'w');
fprintf(fileID,'Load  %s\n\n',TempFile1);
fprintf(fileID,'ppar\n');
fprintf(fileID,'N%d\n\n\n',n_pts);
fprintf(fileID,'psav %s\n',TempFile2);
fprintf(fileID,'Y\n');
fprintf(fileID,'quit\n');
fclose(fileID);


cmd = sprintf('xfoil.exe < xfoil.inp > xfoil.out');
[status,result] = system(cmd);

FoilFine = dlmread(TempFile2,'',0,0);
fileID = fopen([SCADFile,'.scad'],'w');
fprintf(fileID,'%s = [',SCADFile);
for i = 1:length(FoilFine(:,1))
    if i ~= length(FoilFine(:,1))
        fprintf(fileID,'[%7.6f, %7.6f],\n',FoilFine(i,1),FoilFine(i,2));
    else
        fprintf(fileID,'[%7.6f, %7.6f]];',FoilFine(i,1),FoilFine(i,2));
    end
end
fclose(fileID);
delete(TempFile1)
delete(TempFile2)

