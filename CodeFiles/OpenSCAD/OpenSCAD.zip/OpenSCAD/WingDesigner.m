% ----------------------------------------------------------------------- %
% ----------------------------------------------------------------------- %
%{
                            AIAA TECHNICAL NOTE:
               Simultaneously Deriving Wing Twist and Planform
                        from Two Lift Distributions
                          SUPPLIMENTAL MATERIAL

                                Example #2
         Solve for Planform, given Twist, Lift Distrbution, and CL 

                                   2019

                  Michael A. Yukish and Justin D. Valenti
          Aerospace Engineering Department, Penn State University
                                                                         %}
clear % ----------------------------------------------------------------- %
clc   % ----------------------------------------------------------------- %
tic
% ----------------------------------------------------------------------- %
%{
                     There are 3 Matlab Example Files:                        

  1 = Solve for Twist, given Planform, Lift Distrbution, and CL
  2 = Solve for Planform, given Twist, Lift Distrbution, and CL
  3 = Solve for Planform and  Twist, given Lift Distrbution, CL, and AR
                                                                         %}
% ----------------------------------------------------------------------- %

n = 100;           % Set number of spanwise stations
AR = 10;             % Set Aspect Ratio
CL = 0.5;           % Set Design CL
a = 2*pi;           % Define Lift Curve Slope
dalpha = 4*(pi/180);% Set change in alpha to calc off-design conditions

dx = 1/n;                       % Calculate width of spanwise stations
x = transpose(dx/2:dx:1- dx/2); % Discretize the Span
e = ones(n,1);                  % Generate e vector

% Set Wing Twist Here vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv %
%      This block defines an n x 1 vector for wing twist (alpha_t_vec) 
%      Here I chose a simple linear washout.

washout = 3*(pi/180);

if rem(n,2) == 0
    alpha_t_vec = [linspace(-washout,0,n/2)';linspace(0,-washout,n/2)'];
else
    i_mid = ceil(n/2);
    alpha_t_vec = zeros(n,1);
    alpha_t_vec(1:i_mid) = linspace(-washout,0,i_mid)';
    dalpha_di = alpha_t_vec(2) - alpha_t_vec(1);
    alpha_t_vec(i_mid+1:n) = linspace(-dalpha_di,-washout,i_mid-1)';
end
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ %

% Generate Q Matrix, using Toeplitz Generator
Qr = zeros(n,1);
for j = 1:n
    Qr(j) = 1/(1-4*(1-j)^2);
end
Q = toeplitz(Qr);
disp('Q-Matix Generated!')
toc

% Calculate W Matrix
W = a*n/(2*pi)*Q;
fprintf('\nW-Matix Generated!\n')
toc

% Define Lift Distribution
Qi_e = Q\e;         % Precalculate row sums of Q^-1 (Elliptical Dist)
Ls_vec = Qi_e;      % Set Lift distribution shape to Elliptical
L_vec = (CL/(2*AR))*(n/(e'*Ls_vec))*Ls_vec; % Scale lift dist to proper CL


% Solve for alpha  vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv %

fprintf('\nSolving for alpha!\n')

% Calculate alpha min and max
IposCount = 0;
InegCount = 0;
for i = 1:n
    if L_vec(i) >= 0
        IposCount = IposCount + 1;
        Ipos(IposCount,1) = i;
    else
        InegCount = InegCount + 1;
        Ineg(InegCount,1) = i;
    end
end
if exist('Ipos')
    alpha_min = (2/a)*W*L_vec - alpha_t_vec;
    alpha_min = max(alpha_min(Ipos));
end
if exist('Ineg')
    alpha_max = (2/a)*W*L_vec - alpha_t_vec;
    alpha_max = min(alpha_max(Ineg));
end
if exist('alpha_min') == 0
    alpha_min = alpha_max - 2*(AR/a)*min(L_vec);
end
if exist('alpha_max') == 0
    alpha_max = alpha_min + 2*(AR/a)*max(L_vec);
end

if alpha_min > alpha_max
    fprintf('alpha_min = %4.2f > alpha_max = %4.2f!!!\n',...
        (180/pi)*alpha_min, (180/pi)*alpha_max)
    fprintf('INVALID TWIST GIVEN! STOPPING HERE!!!!')
    return
end

% Initialize Bisection Iteration Scheme
alpha_bounds = [alpha_min, alpha_max];
alpha_guess = (alpha_bounds(2) + alpha_bounds(1))/2;
% Begin iteration loop
alphaIteration = 1;
check = 0;
epsilon = 0.00001*n;
WxL_vec = W*L_vec;
while check == 0 && alphaIteration < 100
    
    G_a = sparse(diag((a/2)*(alpha_t_vec + alpha_guess) - WxL_vec));
    n_guess = AR*e'*(G_a\L_vec);
    
    if abs(n - n_guess) < epsilon
        check = 1;
        alpha = alpha_guess;
        disp('ALPHA FOUND!')
    else
        alphaIteration = alphaIteration + 1;
        if  n_guess < n
            alpha_bounds = [alpha_bounds(1),alpha_guess];
        else
            alpha_bounds = [alpha_guess,alpha_bounds(2)];
        end
        alpha_guess = (alpha_bounds(2) + alpha_bounds(1))/2;
        fprintf('\ni = %3.0f ; alpha = %8.4f deg\n',...
            alphaIteration, (180/pi)*alpha_guess)
        toc
    end
    
end
if check == 0
    disp('alpha FAILED TO CONVERGE')
    return
end
%^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ %

% Calculate alpha and chord distributions
alpha_vec = alpha_t_vec + alpha;
c_vec = G_a\L_vec;
C = sparse(diag(c_vec));

% Calculate Lift distributions for off-design CLs
L_vec_PD = (1/2)*((C^(-1) + W)\(a*(alpha_vec-dalpha)));
L_vec_PU = (1/2)*((C^(-1) + W)\(a*(alpha_vec+dalpha)));

CL_PD = (2*AR/n)*e'*L_vec_PD;
CL_PU = (2*AR/n)*e'*L_vec_PU;

% Generate Plots -----------------------------------------------
fprintf('\nPlotting!\n')
figure(1)
subplot(3,1,1)
plot(x,L_vec_PU,'k--', 'LineWidth',2)
hold on
plot(x,L_vec,'k-', 'LineWidth',3)
plot(x,L_vec_PD,'k:', 'LineWidth',2)
hold off
ylabel('Lift','Interpreter','Latex')
title('Lift Distribution (Given)','Interpreter','Latex')
legend(['C_L = ',num2str(CL_PU,3)],...
    ['C_{L,Design} = ',num2str(CL)],...
    ['C_L = ',num2str(CL_PD,3)])

subplot(3,1,2)
plot(x,(180/pi)*alpha_t_vec,'k--', 'LineWidth',3)
text(0.5,(180/pi)*alpha_t_vec(ceil(n/2)) + 0.75,'\alpha_t',...
    'HorizontalAlignment','center')
hold on
plot(x,(180/pi)*(alpha_vec),'k-', 'LineWidth',3)
text(0.5,(180/pi)*alpha_vec(ceil(n/2)) + 0.75,'\alpha_t + \alpha',...
    'HorizontalAlignment','center')
hold off
ylabel('$\alpha$[deg]','Interpreter','Latex')
title('Twist Distribution (Given)','Interpreter','Latex')

subplot(3,1,3)
plot(x,0.25*c_vec,'k-', 'LineWidth',3)
hold on
plot(x,-0.75*c_vec,'k-', 'LineWidth',3)
hold off
daspect([1 1 1])
ylabel('Chord, $c/b$','Interpreter','Latex')
ylim([-0.15 0.1])
xlabel('Spanwise Coordinate, $x/b$','Interpreter','Latex')
title('Planform (Calculated)','Interpreter','Latex')

fprintf('\nDONE!\n')
toc